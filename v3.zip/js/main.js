$(document).ready(function(){
  $("#header").load("layouts/header.html"); 
  $(".footer").load("layouts/footer.html"); 
});
