~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
evasi0n7 1.0.5 (c) 2013-2014 @evad3rs
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

http://evasi0n.com/


DESCRIPTION:

- evasi0n7 1.0.5 is an untethered jailbreak for all iPhone, iPod touch, iPad and iPad mini models running iOS 7.0 through 7.0.5


SYSTEM REQUIREMENTS:

- MacOSX 10.7/10.8/10.9
- Windows (XP minimum)


SUPPORTED FIRMWARES:

- iOS 7.0, 7.0.1, 7.0.2, 7.0.3, 7.0.4, 7.0.5, 7.1beta1, 7.1beta2, 7.1beta3

CHANGES:

- 1.0.5:
  - support for iOS 7.0.5
- 1.0.4:
  - security fix: kernel payload now restores sysent table
  - security fix: code fix for bootstrap Cydia tar files verification
- 1.0.3:
  - updated bundled Cydia, now double checking hfs modifications (for the iPad Mini Retina Cellular reboot loop issue)
  - support for iOS 7.1beta3
- 1.0.2:
  - fix for the iPad 2 wifi reboot loop
- 1.0.1:
  - TaiG is not bundled and not installed anymore with evasi0n7 in chinese language operating systems

INSTRUCTIONS:

- Warning! Over The Air updates of iOS 7 are known to create an issue and make the jailbreak fail. Some devices are then stuck on the Apple Boot Logo. Until we fix that, please restore your device to 7.0.4. with iTunes first.
- Backup your device using iTunes (or iCloud) before using evasi0n. If something breaks, you'll always be able to recover your data.
- Those who use backup passwords in iTunes must disable them for now.  After doing so, iTunes makes a brand new backup.  Please wait for that backup to complete before proceeding!  Feel free to re-enable your backup password after jailbreaking.
- Please disable the lock passcode of your iOS device before using evasi0n. It can cause issues.
- Launch evasi0n, plug in your device, and click "Jailbreak". Just sit back and observe its progress.  Watch for any steps you may be asked to perform.
- Avoid all iOS and iTunes related tasks until evasi0n is complete. Why not just enjoy a brief break from the computer to stretch your legs?
- If the process gets stuck somewhere, it's safe to restart the program, reboot the device (if necessary by holding down Power and Home until it shuts down), and rerun the process.
- If you get an error on OS X 10.8 / 10.9 saying that evasi0n can't be opened, control-click (or right-click) the app and on the revealed context menu, choose 'Open.' On the ensuing dialogue box, choose 'Open' as well.
- Some Cydia tweaks are not yet compatible with iOS 7. The situation will improve as developers will update their software.

FAQ:

If you have any questions regarding the jailbreak process or jailbreaking in general 
please go to the Jailbreak QA dedicated website: http://www.jailbreakqa.com
or see their help page for evasi0n: http://www.jailbreakqa.com/pages/evasi0n-help
or try /r/jailbreak on Reddit: http://reddit.com/r/jailbreak


CREDITS:

evasi0n is a production of @evad3rs. http://evad3rs.com


THANKS TO:

- @phoenixdev for his research
- @Surenix for evad3rs and evasi0n designs
- Hanene Samara for her work on evasi0n GUI
- @ollvm (o-llvm.org) for their support and the early version of Obfuscator-LLVM
